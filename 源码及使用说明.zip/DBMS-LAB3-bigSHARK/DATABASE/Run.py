from init import *
from data import *
from create_view import *

if __name__ == "__main__":
    init_DB()
    insert_data()
    create_view()
