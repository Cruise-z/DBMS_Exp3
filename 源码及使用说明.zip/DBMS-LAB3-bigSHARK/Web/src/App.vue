<template>

  <!-- 主体 -->
  <div style="padding : 0; margin : 0;">
    <!-- 页面跳转时，所有信息将会展现在这里 -->
    <router-view></router-view>
  </div>
  
</template>

<script>

export default{
  name : "App",

}
</script>

